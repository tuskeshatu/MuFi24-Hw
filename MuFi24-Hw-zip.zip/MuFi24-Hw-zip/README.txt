Házi feladat megoldás a "Műszaki és fizikai problémák számítógépes megoldása" (BMETE11AF41 2024/25/1) tárgyhoz.

A mappa a "Problem 8. - N elemű lánckapcsolás" című feladat megoldását tartalmazza.

A feladatot készítette:

Kovács Levente (F5UHYT)
